const axios = require("axios");
const cheerio = require("cheerio");
const express = require("express");
const PORT = 5000;
const app = express();

// Define multiple news sources with their names and URLs
const newsSources = [
  { name: "The Guardian", url: "https://www.theguardian.com/uk" },
  // Add more news sources as needed
];

const aggregatedArticles = [];

// Function to scrape articles from a given source
const scrapeArticles = async (source) => {
  try {
    // Make an HTTP request to the news source
    const response = await axios.get(source.url);
    const html = response.data;
    const $ = cheerio.load(html);

    // Extract articles from the source's HTML structure
    $(".dcr-d1ilyq").each(function () {
      const title = $(this).text();
      const url = $(this).find("a").attr("href");
      // Store the extracted article details along with the source
      aggregatedArticles.push({
        source: source.name,
        title,
        url,
      });
    });
  } catch (error) {
    // Handle errors during the scraping process
    console.error(
      `Error scraping articles from ${source.name}: ${error.message}`
    );
  }
};

// Function to scrape articles from all specified news sources
const scrapeAllArticles = async () => {
  for (const source of newsSources) {
    await scrapeArticles(source);
  }
};

// To display the content in user friendly manner
const generateHtmlPage = (articles) => {
  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Aggregated Articles</title>
      <style>
        body {
          font-family: Arial, sans-serif;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        th, td {
          border: 1px solid #ddd;
          padding: 8px;
          text-align: left;
        }
        th {
          background-color: #f2f2f2;
        }
      </style>
    </head>
    <body>
      <h1>Aggregated Articles</h1>
      <table>
        <thead>
          <tr>
            <th>Source</th>
            <th>Title</th>
           
          </tr>
        </thead>
        <tbody>
          ${articles
            .map(
              (article) => `
            <tr>
              <td>${article.source}</td>
              <td>${article.title}</td>
             
            </tr>
          `
            )
            .join("")}
        </tbody>
      </table>
    </body>
    </html>
  `;

  return html;
};

// Define a route to retrieve aggregated articles
app.get("/", async (req, res) => {
  // Call the function to scrape articles from all sources
  await scrapeAllArticles();

  // Generate an HTML page with the scraped data
  const htmlContent = generateHtmlPage(aggregatedArticles);

  // Send the HTML page as the response
  res.send(htmlContent);
});

// Start the Express server
app.listen(PORT, () => {
  console.log(`Server is listening on PORT ${PORT}!`);
});
